#Angka Muncul Sekali
list1 = [1,1,2,3,5,5,4,4,6,6,7]
list2 = []

def non_duplicate(list):
    for i in list1:
        if list1.count(i) == 1:
            list2.append(i)
    print(list2)


non_duplicate(list1)

#Penjumlahan Angka
num = [1,2,3,4]
target = 5

def twosum(list):
    for i in num:
        for j in num:
            if i + j == target:
                return [num.index(i),num.index(j)]

print(twosum(num))

#Total Kemunculan Desc
items = ["js","js","golang","ruby","ruby","js","js"]
nama_item = set(items)

def total_kemunculan(list):
    for s in nama_item:
        print(s+": " + str(items.count(s)))

total_kemunculan(nama_item)