n = int(input())

# 1. half pyramid pattern
for i in range(n):
    print((i+1)*("* "))

# 2. half inverted pyramid pattern
for i in range(n):
    print((n-i)*"* ")

# 3. half pyramid pattern mirrored
for i in range(n):
    print(((2*n-2)-i*2)*" ",(i+1)*"* ")

# 4. full pyramid pattern
for i in range(n):
    print((n-i-1)*" ",(i+1)*("* "))

# 5. full pyramid pattern mirrored
for i in range(n):
    print(i*" ",(n-i)*"* ")

